var structdoctest_1_1_current_test_case_stats =
[
    [ "failure_flags", "structdoctest_1_1_current_test_case_stats.html#aaa58c52fd07a20e6e4daf19eecb2e2ba", null ],
    [ "numAssertsCurrentTest", "structdoctest_1_1_current_test_case_stats.html#ac8731bc4e8e32b86cf2940f4dcb61dec", null ],
    [ "numAssertsFailedCurrentTest", "structdoctest_1_1_current_test_case_stats.html#a2fb52eed7bcef7322a816f418f0fb942", null ],
    [ "seconds", "structdoctest_1_1_current_test_case_stats.html#a29b1963f1d624d9f939f404726298f48", null ],
    [ "testCaseSuccess", "structdoctest_1_1_current_test_case_stats.html#a2c77d43c1fbab06710da7b5bbba4f3ab", null ]
];