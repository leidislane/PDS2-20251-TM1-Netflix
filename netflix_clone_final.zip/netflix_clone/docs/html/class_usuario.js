var class_usuario =
[
    [ "Usuario", "class_usuario.html#a95c826538a7adf0452be845a299ebd5a", null ],
    [ "adicionarPerfil", "class_usuario.html#a98fb6832e52bea36b3d17c719edf5012", null ],
    [ "autenticar", "class_usuario.html#a52b16540a7e1c0c5443704dbaf957aea", null ],
    [ "getEmail", "class_usuario.html#ab2539a1ac5c44f6d59271ed641243b56", null ],
    [ "getPerfis", "class_usuario.html#a093579995c71b8606eab3a6e21715307", null ],
    [ "getPerfis", "class_usuario.html#a01656e99fbebc41bdacf00e4313d1798", null ]
];