var namespacestd =
[
    [ "basic_istream", "classstd_1_1basic__istream.html", null ],
    [ "basic_ostream", "classstd_1_1basic__ostream.html", null ],
    [ "char_traits", "structstd_1_1char__traits.html", null ],
    [ "tuple", "classstd_1_1tuple.html", null ],
    [ "istream", "namespacestd.html#a3891b048d9663e32878ba34284d62294", null ],
    [ "nullptr_t", "namespacestd.html#a147badd87f1e15108e8dbee257b60b84", null ],
    [ "ostream", "namespacestd.html#a6d1736434ff6d516a3df38cbb7487ea5", null ],
    [ "size_t", "namespacestd.html#a2a88bc267d8fe2228f9ef18e79d79268", null ],
    [ "operator<<", "namespacestd.html#a51374695e8a67674c4308639aae941ca", null ]
];