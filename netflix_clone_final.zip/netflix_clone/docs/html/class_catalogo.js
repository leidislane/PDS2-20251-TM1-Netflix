var class_catalogo =
[
    [ "adicionarConteudo", "class_catalogo.html#a78ad88414538f53cb09bbd9e9f43d059", null ],
    [ "buscarPorTitulo", "class_catalogo.html#a9b0ad0fb903c76bddbf5914889219684", null ],
    [ "carregarDeArquivo", "class_catalogo.html#a33bb060677c3e3de98f16f375e6cc7dc", null ],
    [ "getConteudos", "class_catalogo.html#a14b9933ef84f9b694465100ed9b7e998", null ],
    [ "listarConteudos", "class_catalogo.html#a9b08e656475eeeac7ef70f66714ac150", null ]
];