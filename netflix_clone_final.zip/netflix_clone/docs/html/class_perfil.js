var class_perfil =
[
    [ "Perfil", "class_perfil.html#aa69dd23e7049ee6c7bee391b9d6bbd42", null ],
    [ "adicionarFavorito", "class_perfil.html#a4a2da075530a04179ea76dfdb638bddb", null ],
    [ "assistir", "class_perfil.html#a74ddd3bd82088d37d4fd85e1b8b131ae", null ],
    [ "assistirEpisodio", "class_perfil.html#ac1d77da65d8564acdd6a46d2b4286fee", null ],
    [ "getAvatar", "class_perfil.html#a6825aa793ce29c3beb0af93f0e90153f", null ],
    [ "getHistorico", "class_perfil.html#a6b1a44cbbb55655b04275f9b13e38785", null ],
    [ "getNome", "class_perfil.html#a70487a257f0e2b7313d8470cb149c102", null ],
    [ "isKidsProfile", "class_perfil.html#a2aa2425319f7ba14cdd18d3f2a4aa4b6", null ],
    [ "listarFavoritos", "class_perfil.html#a31e0fa58afa359071c2a89e87080ccee", null ],
    [ "listarHistorico", "class_perfil.html#a419f040d18e92f67a8d153e9b874d660", null ]
];