var structdoctest_1_1_i_context_scope =
[
    [ "stringify", "structdoctest_1_1_i_context_scope.html#affbf0f9bf8107a4a8a805d237288141d", null ]
];