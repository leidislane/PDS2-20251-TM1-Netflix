var class_controle_reproducao =
[
    [ "carregarProgressoDeArquivo", "class_controle_reproducao.html#a99728eb2e5a0f451344e868511962f08", null ],
    [ "getProgresso", "class_controle_reproducao.html#a582a9c07d4bdbca44ee1e05afe915a87", null ],
    [ "getProgressoSerie", "class_controle_reproducao.html#a015ffd2cc04d62734eec14ddd982e839", null ],
    [ "getTempoAssistido", "class_controle_reproducao.html#aee4f96f59360c0a3dc7f4e2cb3ecf9a0", null ],
    [ "getTempoAssistidoEpisodio", "class_controle_reproducao.html#aa9c7d1c2dca8ad0be7d2f08304876ffc", null ],
    [ "iniciar", "class_controle_reproducao.html#a576d6ebd0ac681f6ae212cae89aef330", null ],
    [ "pausar", "class_controle_reproducao.html#af6b1bbed370a3131ed84b45879e5103d", null ],
    [ "pausarEpisodio", "class_controle_reproducao.html#aff40bd639c3404e59e93ee0086559ea5", null ],
    [ "reproduzir", "class_controle_reproducao.html#a0e3fa95669f18fca84290013f5c4b63f", null ],
    [ "reproduzirEpisodio", "class_controle_reproducao.html#a761a504ab3b61ff07d0e0b0e5a876f60", null ],
    [ "retomar", "class_controle_reproducao.html#a06608ecdcc05e5d70b1b9329533ca06e", null ],
    [ "salvarProgressoEmArquivo", "class_controle_reproducao.html#a0bcec021c686e9b782c8e6a936931d60", null ],
    [ "setProgresso", "class_controle_reproducao.html#a8be6cf4879dd3697738c95fbdd1d1cc2", null ],
    [ "setProgressoSerie", "class_controle_reproducao.html#ab86ccc10bf32020d1f30b4bdbc7a3bd8", null ]
];