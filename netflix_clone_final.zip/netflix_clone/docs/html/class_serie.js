var class_serie =
[
    [ "Serie", "class_serie.html#aeb5536d6fff622034e49a7fa85a80281", null ],
    [ "Serie", "class_serie.html#a18575ee56004c688a6dbbf9d3c5ed4ac", null ],
    [ "exibirDetalhes", "class_serie.html#a42a88f9f66d380e6aca53dc33a962115", null ],
    [ "exibirListaEpisodios", "class_serie.html#ac6577c21a46a2440a82663348a6bc8ad", null ],
    [ "getTipo", "class_serie.html#a0e66ae903ca3c68d731af1c8c1d6c3fe", null ],
    [ "getTotalEpisodios", "class_serie.html#a7211e4ac3e8cf09ce92dfe90fd078360", null ]
];