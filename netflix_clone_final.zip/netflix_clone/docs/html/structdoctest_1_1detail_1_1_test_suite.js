var structdoctest_1_1detail_1_1_test_suite =
[
    [ "operator*", "structdoctest_1_1detail_1_1_test_suite.html#ad2551def823db67f1516b78a5e2a967d", null ],
    [ "operator*", "structdoctest_1_1detail_1_1_test_suite.html#a15a89c55da84b7dc5aa40277ab37c7c5", null ],
    [ "m_description", "structdoctest_1_1detail_1_1_test_suite.html#a0458cf84f4f2d308162b26c95a1bbbce", null ],
    [ "m_expected_failures", "structdoctest_1_1detail_1_1_test_suite.html#ab0167ce62046912d83780302cb86adca", null ],
    [ "m_may_fail", "structdoctest_1_1detail_1_1_test_suite.html#aeaf438e6731c002c2447e8e87c46c82b", null ],
    [ "m_no_breaks", "structdoctest_1_1detail_1_1_test_suite.html#a7e86c2494775203d7509434872465d8c", null ],
    [ "m_no_output", "structdoctest_1_1detail_1_1_test_suite.html#af32b6741f56f39846bf750a9685d6446", null ],
    [ "m_should_fail", "structdoctest_1_1detail_1_1_test_suite.html#a3c5953ed157cfc68dfc37cce66fb4103", null ],
    [ "m_skip", "structdoctest_1_1detail_1_1_test_suite.html#a82ecf10ca3db6bff60a087378267caea", null ],
    [ "m_test_suite", "structdoctest_1_1detail_1_1_test_suite.html#ab6260436f6fd52d473c0020ff916753c", null ],
    [ "m_timeout", "structdoctest_1_1detail_1_1_test_suite.html#a430d6e400dd91b9a21c7bb06ede81ec9", null ]
];