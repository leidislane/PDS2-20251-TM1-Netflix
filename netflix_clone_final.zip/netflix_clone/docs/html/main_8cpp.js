var main_8cpp =
[
    [ "carregarCatalogoDeArquivo", "main_8cpp.html#a3ea64b0244389be6c1ef4ff285f65de0", null ],
    [ "carregarProgresso", "main_8cpp.html#a38429cc7b3102da97c724f43ad8e39a9", null ],
    [ "main", "main_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4", null ],
    [ "reproduzirSerie", "main_8cpp.html#a76960624ecbd7fe58f05389624a097bc", null ],
    [ "salvarProgresso", "main_8cpp.html#a322c88d4fd00522c1995825057edfe1e", null ]
];