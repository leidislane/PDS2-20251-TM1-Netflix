var structdoctest_1_1_message_data =
[
    [ "m_file", "structdoctest_1_1_message_data.html#acd1e6a5c4f03ed6e098cdab5956a3e17", null ],
    [ "m_line", "structdoctest_1_1_message_data.html#a7c1cf03250a68db5befbba63b3824d93", null ],
    [ "m_severity", "structdoctest_1_1_message_data.html#a24e0a3f475609ce8e02cecc4cb0d3b48", null ],
    [ "m_string", "structdoctest_1_1_message_data.html#a0ef5cfd7a399ee475d6357b6dcddfe53", null ]
];