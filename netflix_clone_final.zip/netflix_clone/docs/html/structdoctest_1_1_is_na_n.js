var structdoctest_1_1_is_na_n =
[
    [ "IsNaN", "structdoctest_1_1_is_na_n.html#a47f3957c504f7d8bc40dd4014cce5ee1", null ],
    [ "operator bool", "structdoctest_1_1_is_na_n.html#a902478ded2e500009cf2e7a4412965ed", null ],
    [ "operator!", "structdoctest_1_1_is_na_n.html#a73a171e22174f846ffdb68cc33f2b010", null ],
    [ "flipped", "structdoctest_1_1_is_na_n.html#a3c25335f2708d9360b8e92813b3ac17d", null ],
    [ "value", "structdoctest_1_1_is_na_n.html#a6a490d3d5f5561bcf019fefc88291475", null ]
];