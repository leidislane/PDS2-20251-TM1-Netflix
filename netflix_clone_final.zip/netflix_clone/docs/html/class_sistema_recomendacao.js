var class_sistema_recomendacao =
[
    [ "recomendar", "class_sistema_recomendacao.html#aa997264f4eb2a450551a15246f73b02d", null ]
];