var namespaces_dup =
[
    [ "doctest", "namespacedoctest.html", "namespacedoctest" ],
    [ "doctest_detail_test_suite_ns", "namespacedoctest__detail__test__suite__ns.html", [
      [ "getCurrentTestSuite", "namespacedoctest__detail__test__suite__ns.html#a63d04c2e0ba35dff1e33cf0a24ec66c8", null ]
    ] ],
    [ "std", "namespacestd.html", "namespacestd" ]
];