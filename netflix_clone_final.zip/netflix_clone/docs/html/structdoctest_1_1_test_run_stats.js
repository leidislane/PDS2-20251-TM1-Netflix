var structdoctest_1_1_test_run_stats =
[
    [ "numAsserts", "structdoctest_1_1_test_run_stats.html#a58f52d165ab0af01acb7d69a7fc53c3a", null ],
    [ "numAssertsFailed", "structdoctest_1_1_test_run_stats.html#a27c7ff2c0190e4bad60555cdc68d8f30", null ],
    [ "numTestCases", "structdoctest_1_1_test_run_stats.html#a2f4b38f2f6225b798029b64c1d425999", null ],
    [ "numTestCasesFailed", "structdoctest_1_1_test_run_stats.html#adb4acfac3623bf752eff3f8d6ce2ffe7", null ],
    [ "numTestCasesPassingFilters", "structdoctest_1_1_test_run_stats.html#afd49da305793d2c2622f0b33a63e87b6", null ],
    [ "numTestSuitesPassingFilters", "structdoctest_1_1_test_run_stats.html#aecbf62d51a6c96875d72124c27096e1d", null ]
];