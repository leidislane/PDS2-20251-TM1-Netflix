var searchData=
[
  ['genero_0',['genero',['../class_conteudo.html#a73b83c3f9368139b62860bbdb4171036',1,'Conteudo']]],
  ['gnu_5ffile_5fline_1',['gnu_file_line',['../structdoctest_1_1_context_options.html#aab894e731a6fc86cf095288ec7d0c0f2',1,'doctest::ContextOptions']]]
];
