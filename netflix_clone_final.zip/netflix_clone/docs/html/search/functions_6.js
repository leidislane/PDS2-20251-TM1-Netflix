var searchData=
[
  ['get_5factive_5fcontexts_0',['get_active_contexts',['../structdoctest_1_1_i_reporter.html#ad34f2f1954ff43b6e8fe2dc595cec53a',1,'doctest::IReporter']]],
  ['get_5fnum_5factive_5fcontexts_1',['get_num_active_contexts',['../structdoctest_1_1_i_reporter.html#a7d520de46d9104c0eeb02375fabad32d',1,'doctest::IReporter']]],
  ['get_5fnum_5fstringified_5fcontexts_2',['get_num_stringified_contexts',['../structdoctest_1_1_i_reporter.html#ac8b96fef046edc609a3374a61b84797d',1,'doctest::IReporter']]],
  ['get_5fstringified_5fcontexts_3',['get_stringified_contexts',['../structdoctest_1_1_i_reporter.html#a6db31e528efe08c9bc9b4037a2143c3a',1,'doctest::IReporter']]],
  ['getavatar_4',['getAvatar',['../class_perfil.html#a6825aa793ce29c3beb0af93f0e90153f',1,'Perfil']]],
  ['getconteudos_5',['getConteudos',['../class_catalogo.html#a14b9933ef84f9b694465100ed9b7e998',1,'Catalogo']]],
  ['getcontextoptions_6',['getContextOptions',['../namespacedoctest.html#a13c02a469cfc2264d547fc0fc3a55569',1,'doctest']]],
  ['getcurrenttestsuite_7',['getCurrentTestSuite',['../namespacedoctest__detail__test__suite__ns.html#a63d04c2e0ba35dff1e33cf0a24ec66c8',1,'doctest_detail_test_suite_ns']]],
  ['getemail_8',['getEmail',['../class_usuario.html#ab2539a1ac5c44f6d59271ed641243b56',1,'Usuario']]],
  ['getgenero_9',['getGenero',['../class_conteudo.html#a2b303585fe126bda3d63fef6a0c90fc5',1,'Conteudo']]],
  ['gethistorico_10',['getHistorico',['../class_perfil.html#a6b1a44cbbb55655b04275f9b13e38785',1,'Perfil']]],
  ['getnome_11',['getNome',['../class_perfil.html#a70487a257f0e2b7313d8470cb149c102',1,'Perfil']]],
  ['getperfis_12',['getPerfis',['../class_usuario.html#a093579995c71b8606eab3a6e21715307',1,'Usuario::getPerfis()'],['../class_usuario.html#a01656e99fbebc41bdacf00e4313d1798',1,'Usuario::getPerfis() const']]],
  ['getprogresso_13',['getProgresso',['../class_controle_reproducao.html#a582a9c07d4bdbca44ee1e05afe915a87',1,'ControleReproducao']]],
  ['getprogressoserie_14',['getProgressoSerie',['../class_controle_reproducao.html#a015ffd2cc04d62734eec14ddd982e839',1,'ControleReproducao']]],
  ['gettempoassistido_15',['getTempoAssistido',['../class_controle_reproducao.html#aee4f96f59360c0a3dc7f4e2cb3ecf9a0',1,'ControleReproducao']]],
  ['gettempoassistidoepisodio_16',['getTempoAssistidoEpisodio',['../class_controle_reproducao.html#aa9c7d1c2dca8ad0be7d2f08304876ffc',1,'ControleReproducao']]],
  ['gettipo_17',['getTipo',['../class_conteudo.html#a87462bf679d980ff1c9b36ded6cc1d7f',1,'Conteudo::getTipo()'],['../class_filme.html#a887d0215b06cdad5e42bca1c0d981f88',1,'Filme::getTipo()'],['../class_serie.html#a0e66ae903ca3c68d731af1c8c1d6c3fe',1,'Serie::getTipo()']]],
  ['gettitulo_18',['getTitulo',['../class_conteudo.html#a3d023cbcd2f97b055bb71e96b3f129f6',1,'Conteudo']]],
  ['gettotalepisodios_19',['getTotalEpisodios',['../class_serie.html#a7211e4ac3e8cf09ce92dfe90fd078360',1,'Serie']]]
];
