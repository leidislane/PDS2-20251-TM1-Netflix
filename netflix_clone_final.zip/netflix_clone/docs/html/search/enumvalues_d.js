var searchData=
[
  ['white_0',['White',['../namespacedoctest_1_1_color.html#a32e9eaf6013139846e848af6e6cf2b92a0bf060b447441fbf2e4beeb25370a808',1,'doctest::Color']]]
];
