var searchData=
[
  ['serie_0',['Serie',['../class_serie.html',1,'']]],
  ['should_5fstringify_5fas_5funderlying_5ftype_1',['should_stringify_as_underlying_type',['../structdoctest_1_1detail_1_1should__stringify__as__underlying__type.html',1,'doctest::detail']]],
  ['sistemarecomendacao_2',['SistemaRecomendacao',['../class_sistema_recomendacao.html',1,'']]],
  ['string_3',['String',['../classdoctest_1_1_string.html',1,'doctest']]],
  ['stringcontains_4',['StringContains',['../classdoctest_1_1_assert_data_1_1_string_contains.html',1,'doctest::AssertData']]],
  ['stringmaker_5',['StringMaker',['../structdoctest_1_1_string_maker.html',1,'doctest']]],
  ['stringmakerbase_6',['StringMakerBase',['../structdoctest_1_1detail_1_1_string_maker_base.html',1,'doctest::detail']]],
  ['stringmakerbase_3c_20detail_3a_3ahas_5finsertion_5foperator_3c_20t_20_3e_3a_3avalue_7c_7cdetail_3a_3atypes_3a_3ais_5fpointer_3c_20t_20_3e_3a_3avalue_7c_7cdetail_3a_3atypes_3a_3ais_5farray_3c_20t_20_3e_3a_3avalue_20_3e_7',['StringMakerBase&lt; detail::has_insertion_operator&lt; T &gt;::value||detail::types::is_pointer&lt; T &gt;::value||detail::types::is_array&lt; T &gt;::value &gt;',['../structdoctest_1_1detail_1_1_string_maker_base.html',1,'doctest::detail']]],
  ['stringmakerbase_3c_20true_20_3e_8',['StringMakerBase&lt; true &gt;',['../structdoctest_1_1detail_1_1_string_maker_base_3_01true_01_4.html',1,'doctest::detail']]],
  ['subcase_9',['Subcase',['../structdoctest_1_1detail_1_1_subcase.html',1,'doctest::detail']]],
  ['subcasesignature_10',['SubcaseSignature',['../structdoctest_1_1_subcase_signature.html',1,'doctest']]]
];
