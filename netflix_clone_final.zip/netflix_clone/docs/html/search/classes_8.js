var searchData=
[
  ['messagebuilder_0',['MessageBuilder',['../structdoctest_1_1detail_1_1_message_builder.html',1,'doctest::detail']]],
  ['messagedata_1',['MessageData',['../structdoctest_1_1_message_data.html',1,'doctest']]]
];
