var searchData=
[
  ['pausar_0',['pausar',['../class_controle_reproducao.html#af6b1bbed370a3131ed84b45879e5103d',1,'ControleReproducao']]],
  ['pausarepisodio_1',['pausarEpisodio',['../class_controle_reproducao.html#aff40bd639c3404e59e93ee0086559ea5',1,'ControleReproducao']]],
  ['perfil_2',['Perfil',['../class_perfil.html',1,'Perfil'],['../class_perfil.html#aa69dd23e7049ee6c7bee391b9d6bbd42',1,'Perfil::Perfil()']]],
  ['perfil_2ecpp_3',['Perfil.cpp',['../_perfil_8cpp.html',1,'']]],
  ['perfil_2ehpp_4',['Perfil.hpp',['../_perfil_8hpp.html',1,'']]]
];
