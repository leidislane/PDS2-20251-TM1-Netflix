var searchData=
[
  ['pausar_0',['pausar',['../class_controle_reproducao.html#af6b1bbed370a3131ed84b45879e5103d',1,'ControleReproducao']]],
  ['pausarepisodio_1',['pausarEpisodio',['../class_controle_reproducao.html#aff40bd639c3404e59e93ee0086559ea5',1,'ControleReproducao']]],
  ['perfil_2',['Perfil',['../class_perfil.html#aa69dd23e7049ee6c7bee391b9d6bbd42',1,'Perfil']]]
];
