var searchData=
[
  ['addfilter_0',['addFilter',['../classdoctest_1_1_context.html#a60ad57a46c19db2b142468c3acac448a',1,'doctest::Context']]],
  ['adicionarconteudo_1',['adicionarConteudo',['../class_catalogo.html#a78ad88414538f53cb09bbd9e9f43d059',1,'Catalogo']]],
  ['adicionarfavorito_2',['adicionarFavorito',['../class_perfil.html#a4a2da075530a04179ea76dfdb638bddb',1,'Perfil']]],
  ['adicionarperfil_3',['adicionarPerfil',['../class_usuario.html#a98fb6832e52bea36b3d17c719edf5012',1,'Usuario']]],
  ['applycommandline_4',['applyCommandLine',['../classdoctest_1_1_context.html#ad55229220bf9ca74e6e0c6323bf672e1',1,'doctest::Context']]],
  ['approx_5',['Approx',['../structdoctest_1_1_approx.html#a86f0d1b44c1cf095697f23ccdab00802',1,'doctest::Approx']]],
  ['assertdata_6',['AssertData',['../structdoctest_1_1_assert_data.html#ae1f9906888c2dd06b6291ab196f5074e',1,'doctest::AssertData']]],
  ['assertstring_7',['assertString',['../namespacedoctest.html#a44bf1260a82383247d446170810493cf',1,'doctest']]],
  ['assistir_8',['assistir',['../class_perfil.html#a74ddd3bd82088d37d4fd85e1b8b131ae',1,'Perfil']]],
  ['assistirepisodio_9',['assistirEpisodio',['../class_perfil.html#ac1d77da65d8564acdd6a46d2b4286fee',1,'Perfil']]],
  ['autenticar_10',['autenticar',['../class_usuario.html#a52b16540a7e1c0c5443704dbaf957aea',1,'Usuario']]]
];
