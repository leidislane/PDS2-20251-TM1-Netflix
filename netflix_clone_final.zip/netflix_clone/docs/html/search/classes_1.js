var searchData=
[
  ['basic_5fistream_0',['basic_istream',['../classstd_1_1basic__istream.html',1,'std']]],
  ['basic_5fistream_3c_20char_2c_20char_5ftraits_3c_20char_20_3e_20_3e_1',['basic_istream&lt; char, char_traits&lt; char &gt; &gt;',['../classstd_1_1basic__istream.html',1,'std']]],
  ['basic_5fostream_2',['basic_ostream',['../classstd_1_1basic__ostream.html',1,'std']]],
  ['basic_5fostream_3c_20char_2c_20char_5ftraits_3c_20char_20_3e_20_3e_3',['basic_ostream&lt; char, char_traits&lt; char &gt; &gt;',['../classstd_1_1basic__ostream.html',1,'std']]]
];
