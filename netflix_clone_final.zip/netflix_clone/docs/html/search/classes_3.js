var searchData=
[
  ['deferred_5ffalse_0',['deferred_false',['../structdoctest_1_1detail_1_1deferred__false.html',1,'doctest::detail']]]
];
