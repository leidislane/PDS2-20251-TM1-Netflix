var indexSectionsWithContent =
{
  0: "abcdefghilmnopqrstuvwy~",
  1: "abcdefhimpqrstu",
  2: "ds",
  3: "cdfmpsu",
  4: "abcdefgilmoprstu~",
  5: "abcdefghilmnoqrstv",
  6: "afinorst",
  7: "e",
  8: "abcdefgilnrstwy",
  9: "o",
  10: "acdfgimrstw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "related",
  10: "defines"
};

var indexSectionLabels =
{
  0: "Tudo",
  1: "Classes",
  2: "Namespaces",
  3: "Ficheiros",
  4: "Funções",
  5: "Variáveis",
  6: "Definições de tipos",
  7: "Enumerações",
  8: "Valores de enumerações",
  9: "Amigos",
  10: "Macros"
};

