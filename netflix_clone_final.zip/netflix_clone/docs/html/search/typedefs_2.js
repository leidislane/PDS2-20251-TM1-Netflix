var searchData=
[
  ['istream_0',['istream',['../namespacestd.html#a3891b048d9663e32878ba34284d62294',1,'std']]]
];
