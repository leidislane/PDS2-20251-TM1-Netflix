var structdoctest_1_1detail_1_1_i_exception_translator =
[
    [ "translate", "structdoctest_1_1detail_1_1_i_exception_translator.html#a9c56005e4c83c13b859cc2e31102bfbc", null ]
];