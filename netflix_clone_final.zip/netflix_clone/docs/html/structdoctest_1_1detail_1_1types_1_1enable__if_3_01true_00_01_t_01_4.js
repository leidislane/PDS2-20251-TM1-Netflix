var structdoctest_1_1detail_1_1types_1_1enable__if_3_01true_00_01_t_01_4 =
[
    [ "type", "structdoctest_1_1detail_1_1types_1_1enable__if_3_01true_00_01_t_01_4.html#a37e544722a1ede5533999b1b0cee7cbf", null ]
];