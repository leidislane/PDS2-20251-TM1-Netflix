var _controle_reproducao_8hpp =
[
    [ "ControleReproducao", "class_controle_reproducao.html", "class_controle_reproducao" ]
];