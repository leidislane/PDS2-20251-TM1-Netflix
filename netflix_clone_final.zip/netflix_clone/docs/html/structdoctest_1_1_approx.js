var structdoctest_1_1_approx =
[
    [ "Approx", "structdoctest_1_1_approx.html#a86f0d1b44c1cf095697f23ccdab00802", null ],
    [ "epsilon", "structdoctest_1_1_approx.html#a3a9093777280fcf5fd79e79b1c202ba8", null ],
    [ "operator()", "structdoctest_1_1_approx.html#aae907c5ea1c4ac94e134db9e35da7dce", null ],
    [ "scale", "structdoctest_1_1_approx.html#a040114c288b721e97d7cdd22faf69c90", null ],
    [ "operator!=", "structdoctest_1_1_approx.html#ae86972ba14656f422afdcc60cd2cdb08", null ],
    [ "operator!=", "structdoctest_1_1_approx.html#a44d4bbc575291095c884848887538233", null ],
    [ "operator<", "structdoctest_1_1_approx.html#a54ce2536ed164b79688f43e373dcbf7b", null ],
    [ "operator<", "structdoctest_1_1_approx.html#acf32148e34dc6444a3bb4b16e7298279", null ],
    [ "operator<=", "structdoctest_1_1_approx.html#a7f32e572caa5ee152b8ade301fcfd838", null ],
    [ "operator<=", "structdoctest_1_1_approx.html#af2fef67cf4508a446eeaf38dafae661f", null ],
    [ "operator==", "structdoctest_1_1_approx.html#a1b99d0c4c3924a253474e68ae30e1175", null ],
    [ "operator==", "structdoctest_1_1_approx.html#a2b6b56551f113fd12f4a52b4d3e5fd7e", null ],
    [ "operator>", "structdoctest_1_1_approx.html#a12a93e1726180db4091cb2e3b8ba5e30", null ],
    [ "operator>", "structdoctest_1_1_approx.html#a97a6e92b9c9dacc0adb2f76f9faf2924", null ],
    [ "operator>=", "structdoctest_1_1_approx.html#a52e1bcec19171f0ec55cc3a280188a03", null ],
    [ "operator>=", "structdoctest_1_1_approx.html#acf882dbff26c57cd8404da3edd46f45e", null ],
    [ "m_epsilon", "structdoctest_1_1_approx.html#a332ac911453d1289f81bc36068e2bb97", null ],
    [ "m_scale", "structdoctest_1_1_approx.html#aa313c36a9170e7e3157e390a8839396d", null ],
    [ "m_value", "structdoctest_1_1_approx.html#af29d79bf1986ba565a688cb97b10efd4", null ]
];