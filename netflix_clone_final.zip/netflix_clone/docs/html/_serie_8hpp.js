var _serie_8hpp =
[
    [ "Serie", "class_serie.html", "class_serie" ]
];