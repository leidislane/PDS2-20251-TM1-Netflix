var class_filme =
[
    [ "Filme", "class_filme.html#afc28ea2d80382dc82c8545cb14575b54", null ],
    [ "Filme", "class_filme.html#af179383178d9aace3c569df8cfa9d8e8", null ],
    [ "exibirDetalhes", "class_filme.html#a92b4c215ffbd06ddb2b68faa65f4f153", null ],
    [ "getTipo", "class_filme.html#a887d0215b06cdad5e42bca1c0d981f88", null ]
];