var structdoctest_1_1detail_1_1types_1_1remove__reference =
[
    [ "type", "structdoctest_1_1detail_1_1types_1_1remove__reference.html#a3221a0a08e877bda376a3744ceb94656", null ]
];