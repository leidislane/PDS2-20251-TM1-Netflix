var classdoctest_1_1detail_1_1_exception_translator =
[
    [ "ExceptionTranslator", "classdoctest_1_1detail_1_1_exception_translator.html#a3ac05488993c40c6ba55ce51a6bf7eae", null ],
    [ "translate", "classdoctest_1_1detail_1_1_exception_translator.html#a56484c4218a06bbbd1548335a8b64110", null ]
];