var structdoctest_1_1detail_1_1_context_scope_base =
[
    [ "ContextScopeBase", "structdoctest_1_1detail_1_1_context_scope_base.html#a3fff412c7c41aeb8fc0314f3f4503ec4", null ],
    [ "~ContextScopeBase", "structdoctest_1_1detail_1_1_context_scope_base.html#a3adec03d141d955f6b4655fdb1202583", null ],
    [ "ContextScopeBase", "structdoctest_1_1detail_1_1_context_scope_base.html#af3a3ff7ad6b98142ef0f7e1d01912d48", null ],
    [ "ContextScopeBase", "structdoctest_1_1detail_1_1_context_scope_base.html#a13e4ac8d4ef5b7c3361618f6ad5efcfe", null ],
    [ "destroy", "structdoctest_1_1detail_1_1_context_scope_base.html#a6f223de9a972b08bf1b9e9d2d99ab4c6", null ],
    [ "operator=", "structdoctest_1_1detail_1_1_context_scope_base.html#a8a5ae7b7c0455f9c23fc2276c8dbc3e8", null ],
    [ "operator=", "structdoctest_1_1detail_1_1_context_scope_base.html#aa2e4935cdad2ef3bde79fe7c0766612c", null ],
    [ "need_to_destroy", "structdoctest_1_1detail_1_1_context_scope_base.html#a260af2340e01226c6098958ee2b383a2", null ]
];