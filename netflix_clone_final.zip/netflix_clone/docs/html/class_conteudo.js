var class_conteudo =
[
    [ "Conteudo", "class_conteudo.html#a92419333ee3a5cf845e7c3ce3c585742", null ],
    [ "~Conteudo", "class_conteudo.html#a10c711867371c72ae8604b31377ff50d", null ],
    [ "exibirDetalhes", "class_conteudo.html#a9857598dfc624135878762e09ccab165", null ],
    [ "getGenero", "class_conteudo.html#a2b303585fe126bda3d63fef6a0c90fc5", null ],
    [ "getTipo", "class_conteudo.html#a87462bf679d980ff1c9b36ded6cc1d7f", null ],
    [ "getTitulo", "class_conteudo.html#a3d023cbcd2f97b055bb71e96b3f129f6", null ],
    [ "isEhKids", "class_conteudo.html#a51d893e98dfbb6bc30703fbf3ae99ffd", null ],
    [ "classificacao", "class_conteudo.html#a23279e4ba098e987255c070e3b8267b9", null ],
    [ "dataLancamento", "class_conteudo.html#a0539a359966659bd4d1c951c6842f915", null ],
    [ "descricao", "class_conteudo.html#a67141a00ac2d325dc512c476104d5542", null ],
    [ "ehKids", "class_conteudo.html#a48596047cf46e7d89593aaa8d3a8a17f", null ],
    [ "genero", "class_conteudo.html#a73b83c3f9368139b62860bbdb4171036", null ],
    [ "titulo", "class_conteudo.html#aca3b95fd7dafa1fca6131dcc8eab9544", null ],
    [ "trailerURL", "class_conteudo.html#a4a35d6f5f33c71edd2bf083f0c70158d", null ]
];