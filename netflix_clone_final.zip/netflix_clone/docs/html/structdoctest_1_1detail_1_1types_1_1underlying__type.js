var structdoctest_1_1detail_1_1types_1_1underlying__type =
[
    [ "type", "structdoctest_1_1detail_1_1types_1_1underlying__type.html#a9ea68d093bdea7536fcd732fd361c71f", null ]
];